def main():
    print("Templatree CLI started!")
